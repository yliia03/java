package task1;

public class NurseStation implements VitalSignsObserver {
    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("[%s] [Пост медсестри] ТРИВОГА! Пацієнт %s має критичні показники (%s)! Негайний виклик персоналу!%n",
                    time, signs.getPatientName(), signs);
        } else {
            System.out.printf("[%s] [Пост медсестри] Показники пацієнта %s у нормі. Тривоги немає.%n",
                    time, signs.getPatientName());
        }
    }

    @Override
    public String getObserverName() {
        return "Пост медсестри";
    }
}
