package task1;

public class MainTask1 {
    public static void main(String[] args) {
        System.out.println("=== ЗАВДАННЯ 1: МОНІТОРИНГ ПОКАЗНИКІВ ПАЦІЄНТА (ОБЛАСНА ЛІКАРНЯ) ===");
        PatientMonitor monitor = new PatientMonitor("Ковальчук І.П.");

        VitalSignsObserver nurseStation = new NurseStation();
        VitalSignsObserver emr = new ElectronicMedicalRecord();
        VitalSignsObserver doctor1 = new DutyDoctor("Д-р Петренко");
        VitalSignsObserver doctor2 = new DutyDoctor("Д-р Сидоренко");
        VitalSignsObserver attendingDoc = new AttendingDoctor("Д-р Мельник");

        // 1. Підписка отримувачів
        monitor.subscribe("08:00", nurseStation);
        monitor.subscribe("08:00", emr);
        monitor.subscribe("08:00", doctor1);
        monitor.subscribe("08:00", attendingDoc);

        System.out.println("\n--- Крок 1: Передача нормальних показників ---");
        monitor.setVitalSigns("08:15", 74, "120/80", 98);

        System.out.println("\n--- Крок 2: Передача критичної сатурації ---");
        monitor.setVitalSigns("09:10", 128, "90/60", 86);

        System.out.println("\n--- Крок 3: Зміна чергового лікаря та повтор критичних показників ---");
        monitor.unsubscribe("10:00", doctor1);
        monitor.subscribe("10:00", doctor2);
        monitor.setVitalSigns("10:05", 135, "85/55", 84);
    }
}
