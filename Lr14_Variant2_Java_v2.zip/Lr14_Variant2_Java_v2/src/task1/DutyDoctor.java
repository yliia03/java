package task1;

public class DutyDoctor implements VitalSignsObserver {
    private final String doctorName;

    public DutyDoctor(String doctorName) {
        this.doctorName = doctorName;
    }

    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("[%s] [Черговий лікар %s] УВАГА! Отримано екстрене сповіщення по пацієнту %s (%s). Прямую в реанімацію!%n",
                    time, doctorName, signs.getPatientName(), signs);
        } else {
            System.out.printf("[%s] [Черговий лікар %s] Показники пацієнта %s стабільні, втручання не потрібне.%n",
                    time, doctorName, signs.getPatientName());
        }
    }

    @Override
    public String getObserverName() {
        return "Черговий лікар " + doctorName;
    }
}
