package task1;

import java.util.ArrayList;
import java.util.List;

public class PatientMonitor {
    private final String patientName;
    private final List<VitalSignsObserver> observers = new ArrayList<>();

    public PatientMonitor(String patientName) {
        this.patientName = patientName;
    }

    public void subscribe(String time, VitalSignsObserver observer) {
        observers.add(observer);
        System.out.printf("[%s] [Монітор: %s] Підписано отримувача: %s%n", time, patientName, observer.getObserverName());
    }

    public void unsubscribe(String time, VitalSignsObserver observer) {
        observers.remove(observer);
        System.out.printf("[%s] [Монітор: %s] Відписано отримувача: %s%n", time, patientName, observer.getObserverName());
    }

    public void setVitalSigns(String time, int pulse, String bloodPressure, int saturation) {
        PatientVitalSigns signs = new PatientVitalSigns(patientName, pulse, bloodPressure, saturation);
        System.out.printf("[%s] [Монітор: %s] Нові показники: %s%n", time, patientName, signs);
        notifyObservers(time, signs);
    }

    private void notifyObservers(String time, PatientVitalSigns signs) {
        for (VitalSignsObserver observer : new ArrayList<>(observers)) {
            observer.update(time, signs);
        }
    }
}
