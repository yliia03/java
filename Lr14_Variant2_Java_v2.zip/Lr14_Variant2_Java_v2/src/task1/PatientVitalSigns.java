package task1;

public class PatientVitalSigns {
    private final String patientName;
    private final int pulse;
    private final String bloodPressure;
    private final int saturation;

    public PatientVitalSigns(String patientName, int pulse, String bloodPressure, int saturation) {
        this.patientName = patientName;
        this.pulse = pulse;
        this.bloodPressure = bloodPressure;
        this.saturation = saturation;
    }

    public String getPatientName() { return patientName; }
    public int getPulse() { return pulse; }
    public String getBloodPressure() { return bloodPressure; }
    public int getSaturation() { return saturation; }

    public boolean isCritical() {
        return pulse < 50 || pulse > 120 || saturation < 92;
    }

    @Override
    public String toString() {
        return String.format("пульс=%d уд/хв, тиск=%s, сатурація=%d%%", pulse, bloodPressure, saturation);
    }
}
