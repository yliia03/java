package task1;

public class ElectronicMedicalRecord implements VitalSignsObserver {
    @Override
    public void update(String time, PatientVitalSigns signs) {
        System.out.printf("[%s] [Електронна картка] Запис у журнал пацієнта %s: %s (Статус: %s)%n",
                time, signs.getPatientName(), signs, signs.isCritical() ? "КРИТИЧНИЙ" : "НОРМА");
    }

    @Override
    public String getObserverName() {
        return "Електронна картка пацієнта";
    }
}
