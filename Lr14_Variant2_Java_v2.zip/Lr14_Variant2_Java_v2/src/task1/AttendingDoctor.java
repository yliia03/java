package task1;

public class AttendingDoctor implements VitalSignsObserver {
    private final String doctorName;

    public AttendingDoctor(String doctorName) {
        this.doctorName = doctorName;
    }

    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("[%s] [Лікуючий лікар %s] Особисте SMS-повідомлення: критичний стан пацієнта %s (%s)!%n",
                    time, doctorName, signs.getPatientName(), signs);
        }
    }

    @Override
    public String getObserverName() {
        return "Лікуючий лікар " + doctorName;
    }
}
