package task2;

public abstract class MedicalStaff {
    protected OperatingRoomMediator mediator;
    protected final String name;

    public MedicalStaff(String name) {
        this.name = name;
    }

    public void setMediator(OperatingRoomMediator mediator) {
        this.mediator = mediator;
    }

    public String getName() {
        return name;
    }
}
