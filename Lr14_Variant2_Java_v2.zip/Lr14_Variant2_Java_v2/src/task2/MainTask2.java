package task2;

public class MainTask2 {
    public static void main(String[] args) {
        System.out.println("=== ЗАВДАННЯ 2: КООРДИНАЦІЯ ОПЕРАЦІЙНОГО БЛОКУ (ОБЛАСНА ЛІКАРНЯ) ===");

        OperatingBlockCoordinator coordinator = new OperatingBlockCoordinator();

        ScrubNurse nurse = new ScrubNurse("Операційна медсестра Ірина");
        Anesthesiologist anesthesiologist = new Anesthesiologist("Анестезіолог Д-р Кравчук");
        Surgeon surgeon = new Surgeon("Хірург Д-р Бойко");
        BloodLaboratory lab = new BloodLaboratory("Лабораторія крові");
        IntensiveCareUnit icu = new IntensiveCareUnit("Відділення реанімації");
        Perfusionist perfusionist = new Perfusionist("Перфузіолог Д-р Савчук");

        coordinator.registerStaff(nurse, anesthesiologist, surgeon, lab, icu, perfusionist);

        System.out.println("\n--- Крок 1: Медсестра підтверджує готовність інструментів ---");
        nurse.confirmInstrumentsReady("11:00");

        System.out.println("\n--- Крок 2: Хірург запитує кров під час операції ---");
        surgeon.requestBlood("11:45");

        System.out.println("\n--- Крок 3: Хірург повідомляє про завершення операції ---");
        surgeon.finishOperation("13:20");
    }
}
