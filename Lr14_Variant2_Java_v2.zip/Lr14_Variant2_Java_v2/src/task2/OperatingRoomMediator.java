package task2;

public interface OperatingRoomMediator {
    void notify(String time, MedicalStaff sender, String event);
}
