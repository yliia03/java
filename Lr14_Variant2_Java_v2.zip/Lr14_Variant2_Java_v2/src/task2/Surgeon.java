package task2;

public class Surgeon extends MedicalStaff {
    public Surgeon(String name) {
        super(name);
    }

    public void requestBlood(String time) {
        System.out.printf("[%s] [%s] Потрібна донорська кров групи A(II) Rh+ для операції.%n", time, name);
        mediator.notify(time, this, "BLOOD_REQUESTED");
    }

    public void finishOperation(String time) {
        System.out.printf("[%s] [%s] Операцію успішно завершено!%n", time, name);
        mediator.notify(time, this, "OPERATION_FINISHED");
    }
}
