package task2;

public class BloodLaboratory extends MedicalStaff {
    public BloodLaboratory(String name) {
        super(name);
    }

    public void prepareBlood(String time) {
        System.out.printf("[%s] [%s] Запит отримано. Підбір та перевірка крові виконані, пакет передано в оперблок.%n", time, name);
        mediator.notify(time, this, "BLOOD_READY");
    }
}
