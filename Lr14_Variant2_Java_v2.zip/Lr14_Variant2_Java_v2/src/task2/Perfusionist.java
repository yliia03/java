package task2;

// Демонстрація розширюваності: додавання нового учасника без зміни існуючих класів
public class Perfusionist extends MedicalStaff {
    public Perfusionist(String name) {
        super(name);
    }

    public void prepareHeartLungMachine(String time) {
        System.out.printf("[%s] [%s] Апарат штучного кровообігу підготовлено за командою координатора.%n", time, name);
    }
}
