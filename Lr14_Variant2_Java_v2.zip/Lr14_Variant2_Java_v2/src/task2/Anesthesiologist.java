package task2;

public class Anesthesiologist extends MedicalStaff {
    private boolean allowedToStart = false;

    public Anesthesiologist(String name) {
        super(name);
    }

    public void allowAnesthesia(String time) {
        this.allowedToStart = true;
        System.out.printf("[%s] [%s] Отримано дозвіл від координатора. Починаю введення наркозу.%n", time, name);
        mediator.notify(time, this, "ANESTHESIA_STARTED");
    }

    public void tryStartAnesthesia(String time) {
        if (!allowedToStart) {
            System.out.printf("[%s] [%s] Очікую підтвердження готовності інструментів перед наркозом.%n", time, name);
        }
    }
}
