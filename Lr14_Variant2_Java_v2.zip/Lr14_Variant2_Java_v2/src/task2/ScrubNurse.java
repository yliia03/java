package task2;

public class ScrubNurse extends MedicalStaff {
    public ScrubNurse(String name) {
        super(name);
    }

    public void confirmInstrumentsReady(String time) {
        System.out.printf("[%s] [%s] Стерильні інструменти підготовлено та перевірено.%n", time, name);
        mediator.notify(time, this, "INSTRUMENTS_READY");
    }
}
