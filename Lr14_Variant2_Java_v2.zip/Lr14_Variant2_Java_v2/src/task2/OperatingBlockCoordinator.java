package task2;

public class OperatingBlockCoordinator implements OperatingRoomMediator {
    private ScrubNurse scrubNurse;
    private Anesthesiologist anesthesiologist;
    private Surgeon surgeon;
    private BloodLaboratory bloodLaboratory;
    private IntensiveCareUnit icu;
    private Perfusionist perfusionist;

    private boolean instrumentsReady = false;

    public void registerStaff(ScrubNurse nurse, Anesthesiologist anesth, Surgeon surgeon,
                              BloodLaboratory lab, IntensiveCareUnit icu, Perfusionist perf) {
        this.scrubNurse = nurse;
        this.anesthesiologist = anesth;
        this.surgeon = surgeon;
        this.bloodLaboratory = lab;
        this.icu = icu;
        this.perfusionist = perf;

        nurse.setMediator(this);
        anesth.setMediator(this);
        surgeon.setMediator(this);
        lab.setMediator(this);
        icu.setMediator(this);
        if (perf != null) perf.setMediator(this);
    }

    @Override
    public void notify(String time, MedicalStaff sender, String event) {
        switch (event) {
            case "INSTRUMENTS_READY":
                instrumentsReady = true;
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Дозволяю анестезіологу почати наркоз.%n",
                        time, sender.getName());
                anesthesiologist.allowAnesthesia(time);
                if (perfusionist != null) {
                    perfusionist.prepareHeartLungMachine(time);
                }
                break;

            case "ANESTHESIA_STARTED":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Пацієнт під наркозом, хірург може розпочинати.%n",
                        time, sender.getName());
                break;

            case "BLOOD_REQUESTED":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Передаю терміновий запит до лабораторії крові.%n",
                        time, sender.getName());
                bloodLaboratory.prepareBlood(time);
                break;

            case "BLOOD_READY":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Сповіщаю хірурга про готовність крові.%n",
                        time, sender.getName());
                break;

            case "OPERATION_FINISHED":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Сповіщаю реанімацію про підготовку ліжка.%n",
                        time, sender.getName());
                icu.prepareBed(time);
                break;
        }
    }
}
