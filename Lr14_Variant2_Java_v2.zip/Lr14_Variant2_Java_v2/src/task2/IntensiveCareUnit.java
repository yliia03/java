package task2;

public class IntensiveCareUnit extends MedicalStaff {
    public IntensiveCareUnit(String name) {
        super(name);
    }

    public void prepareBed(String time) {
        System.out.printf("[%s] [%s] Отримано сигнал про завершення операції. Реанімаційне ліжко та апаратуру ШВЛ підготовлено!%n", time, name);
    }
}
