import task1.MainTask1;
import task2.MainTask2;

public class Main {
    public static void main(String[] args) {
        MainTask1.main(args);
        System.out.println("\n============================================================\n");
        MainTask2.main(args);
    }
}
