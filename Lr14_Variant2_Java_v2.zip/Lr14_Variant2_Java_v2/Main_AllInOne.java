import java.util.ArrayList;
import java.util.List;

// ============================================================================
// ЗАВДАННЯ 1: МОНІТОРИНГ ПОКАЗНИКІВ ПАЦІЄНТА (ШАБЛОН OBSERVER)
// ============================================================================

class PatientVitalSigns {
    private final String patientName;
    private final int pulse;
    private final String bloodPressure;
    private final int saturation;

    public PatientVitalSigns(String patientName, int pulse, String bloodPressure, int saturation) {
        this.patientName = patientName;
        this.pulse = pulse;
        this.bloodPressure = bloodPressure;
        this.saturation = saturation;
    }

    public String getPatientName() { return patientName; }
    public int getPulse() { return pulse; }
    public String getBloodPressure() { return bloodPressure; }
    public int getSaturation() { return saturation; }

    public boolean isCritical() {
        return pulse < 50 || pulse > 120 || saturation < 92;
    }

    @Override
    public String toString() {
        return String.format("пульс=%d уд/хв, тиск=%s, сатурація=%d%%", pulse, bloodPressure, saturation);
    }
}

interface VitalSignsObserver {
    void update(String time, PatientVitalSigns signs);
    String getObserverName();
}

class PatientMonitor {
    private final String patientName;
    private final List<VitalSignsObserver> observers = new ArrayList<>();

    public PatientMonitor(String patientName) {
        this.patientName = patientName;
    }

    public void subscribe(String time, VitalSignsObserver observer) {
        observers.add(observer);
        System.out.printf("[%s] [Монітор: %s] Підписано отримувача: %s%n", time, patientName, observer.getObserverName());
    }

    public void unsubscribe(String time, VitalSignsObserver observer) {
        observers.remove(observer);
        System.out.printf("[%s] [Монітор: %s] Відписано отримувача: %s%n", time, patientName, observer.getObserverName());
    }

    public void setVitalSigns(String time, int pulse, String bloodPressure, int saturation) {
        PatientVitalSigns signs = new PatientVitalSigns(patientName, pulse, bloodPressure, saturation);
        System.out.printf("[%s] [Монітор: %s] Нові показники: %s%n", time, patientName, signs);
        notifyObservers(time, signs);
    }

    private void notifyObservers(String time, PatientVitalSigns signs) {
        for (VitalSignsObserver observer : new ArrayList<>(observers)) {
            observer.update(time, signs);
        }
    }
}

class NurseStation implements VitalSignsObserver {
    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("[%s] [Пост медсестри] ТРИВОГА! Пацієнт %s має критичні показники (%s)! Негайний виклик персоналу!%n",
                    time, signs.getPatientName(), signs);
        } else {
            System.out.printf("[%s] [Пост медсестри] Показники пацієнта %s у нормі. Тривоги немає.%n",
                    time, signs.getPatientName());
        }
    }

    @Override
    public String getObserverName() { return "Пост медсестри"; }
}

class ElectronicMedicalRecord implements VitalSignsObserver {
    @Override
    public void update(String time, PatientVitalSigns signs) {
        System.out.printf("[%s] [Електронна картка] Запис у журнал пацієнта %s: %s (Статус: %s)%n",
                time, signs.getPatientName(), signs, signs.isCritical() ? "КРИТИЧНИЙ" : "НОРМА");
    }

    @Override
    public String getObserverName() { return "Електронна картка пацієнта"; }
}

class DutyDoctor implements VitalSignsObserver {
    private final String doctorName;

    public DutyDoctor(String doctorName) { this.doctorName = doctorName; }

    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("[%s] [Черговий лікар %s] УВАГА! Отримано екстрене сповіщення по пацієнту %s (%s). Прямую в реанімацію!%n",
                    time, doctorName, signs.getPatientName(), signs);
        } else {
            System.out.printf("[%s] [Черговий лікар %s] Показники пацієнта %s стабільні, втручання не потрібне.%n",
                    time, doctorName, signs.getPatientName());
        }
    }

    @Override
    public String getObserverName() { return "Черговий лікар " + doctorName; }
}

class AttendingDoctor implements VitalSignsObserver {
    private final String doctorName;

    public AttendingDoctor(String doctorName) { this.doctorName = doctorName; }

    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("[%s] [Лікуючий лікар %s] Особисте SMS-повідомлення: критичний стан пацієнта %s (%s)!%n",
                    time, doctorName, signs.getPatientName(), signs);
        }
    }

    @Override
    public String getObserverName() { return "Лікуючий лікар " + doctorName; }
}

// ============================================================================
// ЗАВДАННЯ 2: ОПЕРАЦІЙНИЙ БЛОК (ШАБЛОН MEDIATOR)
// ============================================================================

interface OperatingRoomMediator {
    void notify(String time, MedicalStaff sender, String event);
}

abstract class MedicalStaff {
    protected OperatingRoomMediator mediator;
    protected final String name;

    public MedicalStaff(String name) { this.name = name; }
    public void setMediator(OperatingRoomMediator mediator) { this.mediator = mediator; }
    public String getName() { return name; }
}

class ScrubNurse extends MedicalStaff {
    public ScrubNurse(String name) { super(name); }
    public void confirmInstrumentsReady(String time) {
        System.out.printf("[%s] [%s] Стерильні інструменти підготовлено та перевірено.%n", time, name);
        mediator.notify(time, this, "INSTRUMENTS_READY");
    }
}

class Anesthesiologist extends MedicalStaff {
    private boolean allowedToStart = false;
    public Anesthesiologist(String name) { super(name); }
    public void allowAnesthesia(String time) {
        this.allowedToStart = true;
        System.out.printf("[%s] [%s] Отримано дозвіл від координатора. Починаю введення наркозу.%n", time, name);
        mediator.notify(time, this, "ANESTHESIA_STARTED");
    }
}

class Surgeon extends MedicalStaff {
    public Surgeon(String name) { super(name); }
    public void requestBlood(String time) {
        System.out.printf("[%s] [%s] Потрібна донорська кров групи A(II) Rh+ для операції.%n", time, name);
        mediator.notify(time, this, "BLOOD_REQUESTED");
    }
    public void finishOperation(String time) {
        System.out.printf("[%s] [%s] Операцію успішно завершено!%n", time, name);
        mediator.notify(time, this, "OPERATION_FINISHED");
    }
}

class BloodLaboratory extends MedicalStaff {
    public BloodLaboratory(String name) { super(name); }
    public void prepareBlood(String time) {
        System.out.printf("[%s] [%s] Запит отримано. Підбір та перевірка крові виконані, пакет передано в оперблок.%n", time, name);
        mediator.notify(time, this, "BLOOD_READY");
    }
}

class IntensiveCareUnit extends MedicalStaff {
    public IntensiveCareUnit(String name) { super(name); }
    public void prepareBed(String time) {
        System.out.printf("[%s] [%s] Отримано сигнал про завершення операції. Реанімаційне ліжко та апаратуру ШВЛ підготовлено!%n", time, name);
    }
}

class Perfusionist extends MedicalStaff {
    public Perfusionist(String name) { super(name); }
    public void prepareHeartLungMachine(String time) {
        System.out.printf("[%s] [%s] Апарат штучного кровообігу підготовлено за командою координатора.%n", time, name);
    }
}

class OperatingBlockCoordinator implements OperatingRoomMediator {
    private ScrubNurse scrubNurse;
    private Anesthesiologist anesthesiologist;
    private Surgeon surgeon;
    private BloodLaboratory bloodLaboratory;
    private IntensiveCareUnit icu;
    private Perfusionist perfusionist;

    public void registerStaff(ScrubNurse nurse, Anesthesiologist anesth, Surgeon surgeon,
                              BloodLaboratory lab, IntensiveCareUnit icu, Perfusionist perf) {
        this.scrubNurse = nurse;
        this.anesthesiologist = anesth;
        this.surgeon = surgeon;
        this.bloodLaboratory = lab;
        this.icu = icu;
        this.perfusionist = perf;

        nurse.setMediator(this);
        anesth.setMediator(this);
        surgeon.setMediator(this);
        lab.setMediator(this);
        icu.setMediator(this);
        if (perf != null) perf.setMediator(this);
    }

    @Override
    public void notify(String time, MedicalStaff sender, String event) {
        switch (event) {
            case "INSTRUMENTS_READY":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Дозволяю анестезіологу почати наркоз.%n",
                        time, sender.getName());
                anesthesiologist.allowAnesthesia(time);
                if (perfusionist != null) {
                    perfusionist.prepareHeartLungMachine(time);
                }
                break;
            case "ANESTHESIA_STARTED":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Пацієнт під наркозом, хірург може розпочинати.%n",
                        time, sender.getName());
                break;
            case "BLOOD_REQUESTED":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Передаю терміновий запит до лабораторії крові.%n",
                        time, sender.getName());
                bloodLaboratory.prepareBlood(time);
                break;
            case "BLOOD_READY":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Сповіщаю хірурга про готовність крові.%n",
                        time, sender.getName());
                break;
            case "OPERATION_FINISHED":
                System.out.printf("[%s] [Координатор оперблоку] Ініціатор: %s -> Сповіщаю реанімацію про підготовку ліжка.%n",
                        time, sender.getName());
                icu.prepareBed(time);
                break;
        }
    }
}

// ============================================================================
// ГОЛОВНИЙ КЛАС З ОДНИМ МЕТОДОМ MAIN
// ============================================================================
public class Main {
    public static void main(String[] args) {
        runTask1();
        System.out.println("\n====================================================================\n");
        runTask2();
    }

    public static void runTask1() {
        System.out.println("=== ЗАВДАННЯ 1: МОНІТОРИНГ ПОКАЗНИКІВ ПАЦІЄНТА (ОБЛАСНА ЛІКАРНЯ) ===");
        PatientMonitor monitor = new PatientMonitor("Ковальчук І.П.");

        VitalSignsObserver nurseStation = new NurseStation();
        VitalSignsObserver emr = new ElectronicMedicalRecord();
        VitalSignsObserver doctor1 = new DutyDoctor("Д-р Петренко");
        VitalSignsObserver doctor2 = new DutyDoctor("Д-р Сидоренко");
        VitalSignsObserver attendingDoc = new AttendingDoctor("Д-р Мельник");

        monitor.subscribe("08:00", nurseStation);
        monitor.subscribe("08:00", emr);
        monitor.subscribe("08:00", doctor1);
        monitor.subscribe("08:00", attendingDoc);

        System.out.println("\n--- Крок 1: Передача нормальних показників ---");
        monitor.setVitalSigns("08:15", 74, "120/80", 98);

        System.out.println("\n--- Крок 2: Передача критичної сатурації ---");
        monitor.setVitalSigns("09:10", 128, "90/60", 86);

        System.out.println("\n--- Крок 3: Зміна чергового лікаря та повтор критичних показників ---");
        monitor.unsubscribe("10:00", doctor1);
        monitor.subscribe("10:00", doctor2);
        monitor.setVitalSigns("10:05", 135, "85/55", 84);
    }

    public static void runTask2() {
        System.out.println("=== ЗАВДАННЯ 2: КООРДИНАЦІЯ ОПЕРАЦІЙНОГО БЛОКУ (ОБЛАСНА ЛІКАРНЯ) ===");
        OperatingBlockCoordinator coordinator = new OperatingBlockCoordinator();

        ScrubNurse nurse = new ScrubNurse("Операційна медсестра Ірина");
        Anesthesiologist anesthesiologist = new Anesthesiologist("Анестезіолог Д-р Кравчук");
        Surgeon surgeon = new Surgeon("Хірург Д-р Бойко");
        BloodLaboratory lab = new BloodLaboratory("Лабораторія крові");
        IntensiveCareUnit icu = new IntensiveCareUnit("Відділення реанімації");
        Perfusionist perfusionist = new Perfusionist("Перфузіолог Д-р Савчук");

        coordinator.registerStaff(nurse, anesthesiologist, surgeon, lab, icu, perfusionist);

        System.out.println("\n--- Крок 1: Медсестра підтверджує готовність інструментів ---");
        nurse.confirmInstrumentsReady("11:00");

        System.out.println("\n--- Крок 2: Хірург запитує кров під час операції ---");
        surgeon.requestBlood("11:45");

        System.out.println("\n--- Крок 3: Хірург повідомляє про завершення операції ---");
        surgeon.finishOperation("13:20");
    }
}
