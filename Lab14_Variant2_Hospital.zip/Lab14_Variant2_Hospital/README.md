# Лабораторна робота № 14 — Поведінкові шаблони проєктування (Observer, Mediator)

**Варіант 2:** Обласна лікарня  
**Мова реалізації:** Java  

## Розподіл ролей у команді
* **Студент А:** реалізація Завдання 1 — «Моніторинг показників пацієнта» (шаблон **Observer**, пакет `src/task1/`), перехресне рев'ю Завдання 2.
* **Студент Б:** реалізація Завдання 2 — «Координація операційного блоку» (шаблон **Mediator**, пакет `src/task2/`), перехресне рев'ю Завдання 1.

## Структура проєкту
* `src/Main.java` — єдиний головний файл запуску обох демонстраційних сценаріїв.
* `src/task1/` — реалізація шаблону **Observer** (`PatientMonitor`, `VitalSignsObserver`, `PatientVitalSigns`, `NurseStation`, `ElectronicMedicalRecord`, `DutyDoctor`, `AttendingDoctor`, `MainTask1`).
* `src/task2/` — реалізація шаблону **Mediator** (`OperatingRoomMediator`, `OperatingBlockCoordinator`, `MedicalStaff`, `ScrubNurse`, `Anesthesiologist`, `Perfusionist`, `Surgeon`, `BloodLaboratory`, `IntensiveCareUnit`, `MainTask2`).
* `docs/diagrams/` — UML-діаграми класів у форматах `.png` та `.puml`.
* `REVIEW.md` — звіт про перехресне рев'ю коду партнера.

## Інструкція запуску
```bash
javac -encoding UTF-8 -d out src/Main.java src/task1/*.java src/task2/*.java
java -cp out Main
```
