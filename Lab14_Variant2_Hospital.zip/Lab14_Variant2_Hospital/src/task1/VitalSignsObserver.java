package task1;

public interface VitalSignsObserver {
    void update(String time, PatientVitalSigns signs);
}
