package task1;

public class AttendingDoctor implements VitalSignsObserver {
    private final String doctorName;

    public AttendingDoctor(String doctorName) {
        this.doctorName = doctorName;
    }

    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("   -> [Лікуючий лікар %s] SMS-повідомлення: критичний стан пацієнта %s!%n",
                    doctorName, signs.patientName);
        }
    }
}
