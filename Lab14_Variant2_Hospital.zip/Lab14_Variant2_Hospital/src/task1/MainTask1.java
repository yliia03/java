package task1;

public class MainTask1 {
    public static void main(String[] args) {
        System.out.println("=== ЗАВДАННЯ 1: МОНІТОРИНГ ПОКАЗНИКІВ ПАЦІЄНТА (ШАБЛОН OBSERVER) ===");
        PatientMonitor monitor = new PatientMonitor("Палата інтенсивної терапії №3");

        VitalSignsObserver nurseStation = new NurseStation("Пост медсестри №1");
        VitalSignsObserver emr = new ElectronicMedicalRecord();
        VitalSignsObserver dutyDrPetrenko = new DutyDoctor("Д-р Петренко");
        VitalSignsObserver attendingDrKoval = new AttendingDoctor("Д-р Коваль");

        monitor.subscribe(nurseStation);
        monitor.subscribe(emr);
        monitor.subscribe(dutyDrPetrenko);
        monitor.subscribe(attendingDrKoval);

        System.out.println();
        System.out.println("--- Крок 1: Планове вимірювання показників (норма) ---");
        monitor.setVitalSigns("09:00", new PatientVitalSigns("Мельник О.В.", 76, "120/80", 98));

        System.out.println();
        System.out.println("--- Крок 2: Різке погіршення стану пацієнта (критичні показники) ---");
        monitor.setVitalSigns("10:15", new PatientVitalSigns("Мельник О.В.", 135, "90/60", 88));

        System.out.println();
        System.out.println("--- Крок 3: Зміна чергового лікаря (відписка Петренка, підписка Сидоренка) ---");
        monitor.unsubscribe(dutyDrPetrenko);
        VitalSignsObserver dutyDrSydorenko = new DutyDoctor("Д-р Сидоренко");
        monitor.subscribe(dutyDrSydorenko);

        monitor.setVitalSigns("11:00", new PatientVitalSigns("Мельник О.В.", 84, "115/75", 96));
    }
}
