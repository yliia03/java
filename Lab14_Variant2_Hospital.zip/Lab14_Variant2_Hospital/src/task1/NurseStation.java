package task1;

public class NurseStation implements VitalSignsObserver {
    private final String stationName;

    public NurseStation(String stationName) {
        this.stationName = stationName;
    }

    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("   -> [%s] ТРИВОГА НА ПОСТУ! Терміново перевірити пацієнта %s (SpO2=%d%%, пульс=%d)!%n",
                    stationName, signs.patientName, signs.spo2, signs.heartRate);
        } else {
            System.out.printf("   -> [%s] Показники пацієнта %s у межах норми.%n", stationName, signs.patientName);
        }
    }
}
