package task1;

import java.util.ArrayList;
import java.util.List;

public class PatientMonitor {
    private final String wardName;
    private final List<VitalSignsObserver> observers = new ArrayList<>();

    public PatientMonitor(String wardName) {
        this.wardName = wardName;
    }

    public void subscribe(VitalSignsObserver observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }

    public void unsubscribe(VitalSignsObserver observer) {
        observers.remove(observer);
    }

    public void setVitalSigns(String time, PatientVitalSigns signs) {
        System.out.printf("[%s] [Монітор %s] Нові показники -> %s%n", time, wardName, signs);
        notifyObservers(time, signs);
    }

    private void notifyObservers(String time, PatientVitalSigns signs) {
        for (VitalSignsObserver observer : new ArrayList<>(observers)) {
            observer.update(time, signs);
        }
    }
}
