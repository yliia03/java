package task1;

public class PatientVitalSigns {
    public final String patientName;
    public final int heartRate;
    public final String bloodPressure;
    public final int spo2;

    public PatientVitalSigns(String patientName, int heartRate, String bloodPressure, int spo2) {
        this.patientName = patientName;
        this.heartRate = heartRate;
        this.bloodPressure = bloodPressure;
        this.spo2 = spo2;
    }

    public boolean isCritical() {
        return heartRate < 50 || heartRate > 120 || spo2 < 92;
    }

    @Override
    public String toString() {
        return String.format("Пацієнт: %s | Пульс: %d уд/хв | Тиск: %s | SpO2: %d%% %s",
                patientName, heartRate, bloodPressure, spo2, isCritical() ? "[КРИТИЧНО!]" : "[Норма]");
    }
}
