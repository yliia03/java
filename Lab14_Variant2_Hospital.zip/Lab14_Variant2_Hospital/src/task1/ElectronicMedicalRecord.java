package task1;

import java.util.ArrayList;
import java.util.List;

public class ElectronicMedicalRecord implements VitalSignsObserver {
    private final List<String> history = new ArrayList<>();

    @Override
    public void update(String time, PatientVitalSigns signs) {
        String entry = "[" + time + "] " + signs;
        history.add(entry);
        System.out.println("   -> [Електронна картка] Записано в історію хвороби (" + history.size() + " записів).");
    }
}
