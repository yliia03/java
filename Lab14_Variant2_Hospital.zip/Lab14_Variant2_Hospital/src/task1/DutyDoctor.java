package task1;

public class DutyDoctor implements VitalSignsObserver {
    private final String doctorName;

    public DutyDoctor(String doctorName) {
        this.doctorName = doctorName;
    }

    @Override
    public void update(String time, PatientVitalSigns signs) {
        if (signs.isCritical()) {
            System.out.printf("   -> [Черговий лікар %s] Екстрений виклик у палату до пацієнта %s!%n",
                    doctorName, signs.patientName);
        } else {
            System.out.printf("   -> [Черговий лікар %s] Ознайомлений із плановими показниками.%n", doctorName);
        }
    }
}
