package task2;

public class OperatingBlockCoordinator implements OperatingRoomMediator {
    private ScrubNurse nurse;
    private Anesthesiologist anesthesiologist;
    private Perfusionist perfusionist;
    private Surgeon surgeon;
    private BloodLaboratory bloodLab;
    private IntensiveCareUnit icu;

    public void registerStaff(ScrubNurse nurse, Anesthesiologist anesthesiologist,
                              Perfusionist perfusionist, Surgeon surgeon,
                              BloodLaboratory bloodLab, IntensiveCareUnit icu) {
        this.nurse = nurse;
        this.anesthesiologist = anesthesiologist;
        this.perfusionist = perfusionist;
        this.surgeon = surgeon;
        this.bloodLab = bloodLab;
        this.icu = icu;

        nurse.setMediator(this);
        anesthesiologist.setMediator(this);
        perfusionist.setMediator(this);
        surgeon.setMediator(this);
        bloodLab.setMediator(this);
        icu.setMediator(this);
    }

    @Override
    public void notify(String time, MedicalStaff sender, String event) {
        switch (event) {
            case "INSTRUMENTS_READY":
                System.out.printf("[%s] [Координатор] Інструменти готові -> даю команду анестезіологу та перфузіологу.%n", time);
                anesthesiologist.startAnesthesia(time);
                perfusionist.prepareHeartLungMachine(time);
                break;
            case "ANESTHESIA_READY":
                System.out.printf("[%s] [Координатор] Пацієнт у наркозі -> дозволяю хірургу почати операцію.%n", time);
                surgeon.startOperation(time);
                break;
            case "BLOOD_REQUESTED":
                System.out.printf("[%s] [Координатор] Передаю терміновий запит хірурга в лабораторію крові.%n", time);
                bloodLab.prepareBloodUnits(time);
                break;
            case "BLOOD_READY":
                System.out.printf("[%s] [Координатор] Повідомляю хірурга про доставку крові.%n", time);
                surgeon.receiveBlood(time);
                break;
            case "OPERATION_FINISHED":
                System.out.printf("[%s] [Координатор] Операцію завершено -> сповіщаю відділення реанімації.%n", time);
                icu.prepareBed(time);
                break;
            default:
                System.out.printf("[%s] [Координатор] Невідома подія: %s%n", time, event);
        }
    }
}
