package task2;

public class Anesthesiologist extends MedicalStaff {
    public Anesthesiologist(String name) {
        super(name);
    }

    public void startAnesthesia(String time) {
        System.out.printf("[%s] [%s] Отримано дозвіл -> вводжу пацієнта в наркоз.%n", time, name);
        mediator.notify(time, this, "ANESTHESIA_READY");
    }
}
