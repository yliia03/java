package task2;

public class Surgeon extends MedicalStaff {
    public Surgeon(String name) {
        super(name);
    }

    public void startOperation(String time) {
        System.out.printf("[%s] [%s] Наркоз діє -> розпочинаю хірургічне втручання.%n", time, name);
    }

    public void requestBlood(String time) {
        System.out.printf("[%s] [%s] Потрібна донорська кров групи A(II) Rh+!%n", time, name);
        mediator.notify(time, this, "BLOOD_REQUESTED");
    }

    public void receiveBlood(String time) {
        System.out.printf("[%s] [%s] Донорську кров отримано, продовжую операцію.%n", time, name);
    }

    public void finishOperation(String time) {
        System.out.printf("[%s] [%s] Операцію успішно завершено!%n", time, name);
        mediator.notify(time, this, "OPERATION_FINISHED");
    }
}
