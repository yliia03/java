package task2;

public class MainTask2 {
    public static void main(String[] args) {
        System.out.println("=== ЗАВДАННЯ 2: КООРДИНАЦІЯ ОПЕРАЦІЙНОГО БЛОКУ (ШАБЛОН MEDIATOR) ===");
        OperatingBlockCoordinator coordinator = new OperatingBlockCoordinator();

        ScrubNurse nurse = new ScrubNurse("Операційна медсестра Ірина");
        Anesthesiologist anesthesiologist = new Anesthesiologist("Анестезіолог Д-р Бойко");
        Perfusionist perfusionist = new Perfusionist("Перфузіолог Д-р Ткаченко");
        Surgeon surgeon = new Surgeon("Хірург Д-р Мороз");
        BloodLaboratory bloodLab = new BloodLaboratory("Лабораторія крові");
        IntensiveCareUnit icu = new IntensiveCareUnit("Відділення реанімації");

        coordinator.registerStaff(nurse, anesthesiologist, perfusionist, surgeon, bloodLab, icu);

        System.out.println();
        System.out.println("--- Етап 1: Підготовка до операції ---");
        nurse.prepareInstruments("12:00");

        System.out.println();
        System.out.println("--- Етап 2: Запит донорської крові під час операції ---");
        surgeon.requestBlood("12:45");

        System.out.println();
        System.out.println("--- Етап 3: Завершення операції та переведення в реанімацію ---");
        surgeon.finishOperation("14:10");
    }
}
