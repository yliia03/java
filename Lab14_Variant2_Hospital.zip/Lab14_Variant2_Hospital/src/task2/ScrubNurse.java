package task2;

public class ScrubNurse extends MedicalStaff {
    public ScrubNurse(String name) {
        super(name);
    }

    public void prepareInstruments(String time) {
        System.out.printf("[%s] [%s] Стерильні хірургічні інструменти підготовлено.%n", time, name);
        mediator.notify(time, this, "INSTRUMENTS_READY");
    }
}
