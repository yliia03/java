package task2;

public class IntensiveCareUnit extends MedicalStaff {
    public IntensiveCareUnit(String name) {
        super(name);
    }

    public void prepareBed(String time) {
        System.out.printf("[%s] [%s] Реанімаційне ліжко та апарат ШВЛ готові до прийому пацієнта.%n", time, name);
    }
}
