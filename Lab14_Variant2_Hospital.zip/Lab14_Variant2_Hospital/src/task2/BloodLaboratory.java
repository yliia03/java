package task2;

public class BloodLaboratory extends MedicalStaff {
    public BloodLaboratory(String name) {
        super(name);
    }

    public void prepareBloodUnits(String time) {
        System.out.printf("[%s] [%s] Підібрано та доставлено 2 дози сумісної крові.%n", time, name);
        mediator.notify(time, this, "BLOOD_READY");
    }
}
