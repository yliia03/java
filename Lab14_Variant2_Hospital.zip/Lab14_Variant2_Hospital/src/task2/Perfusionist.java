package task2;

public class Perfusionist extends MedicalStaff {
    public Perfusionist(String name) {
        super(name);
    }

    public void prepareHeartLungMachine(String time) {
        System.out.printf("[%s] [%s] Апарат штучного кровообігу підключено та перевірено.%n", time, name);
    }
}
